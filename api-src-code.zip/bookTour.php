<?php
require_once "connectDB.php";
$userId = 0;
if (!empty($_POST['userId'])) {
    $userId = $_POST['userId'];
}
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$tourId = $_POST['tourId'];
$date = $_POST['date'];
$seats = $_POST['seatList'];
$paymentMethod = $_POST['paymentMethod'];
$paymentInformation = $_POST['paymentInformation'];
$totalAmount = $_POST['totalAmount'];
$qrCode = bin2hex(random_bytes(50));
$query = "INSERT INTO ticket VALUES(null, '$userId', '$name', '$email', '$phone', '$tourId', '$date', '$seats', '$paymentMethod', '$paymentInformation', '$totalAmount', '$qrCode')";
if (mysqli_query($connect, $query)) {
    $query = "SELECT seatSelected FROM tour WHERE id = '$tourId' LIMIT 1";
    $data = mysqli_fetch_assoc(mysqli_query($connect, $query));
    if (json_encode($data['seatSelected']) !== 'null') {
        $data = json_encode(array_merge(json_decode($data['seatSelected']), json_decode($seats)));
        if ($data !== 'null') {
            $query = "UPDATE tour SET seatSelected = '$data' WHERE id = '$tourId'";
            $data = mysqli_query($connect, $query);
            if (!$data) {
                http_response_code(500);
                die('An error occurred. Update Seat selected error: '. $connect->error);
            }
        } else {
            http_response_code(500);
            die('An error occurred. Array error: '. $connect->error);
        }
    } else {
        $query = "UPDATE tour SET seatSelected = '$seats' WHERE id = '$tourId'";
        $data = mysqli_query($connect, $query);
        if (!$data) {
            http_response_code(500);
            die('An error occurred. Update Seat selected error: '. $connect->error);
        }
    }

    $query = "SELECT * FROM ticket WHERE qrCode = '$qrCode' LIMIT 1";
    $data = mysqli_query($connect, $query);
    if ($data) {
        if (!empty($ticket = mysqli_fetch_assoc($data))) {
            $tourId = $ticket['tourId'];
            $query = "SELECT * FROM tour WHERE id = '$tourId' LIMIT 1";
            if ($data = mysqli_query($connect, $query)) {
                if (!empty($tour = mysqli_fetch_assoc($data))) {
                    $ticket['seatList'] = json_decode($ticket['seatList']);
                    $ticket['tourData'] = $tour;
                    $ticket['tourData']['seatSelected'] = json_decode($ticket['tourData']['seatSelected']);
            	    echo json_encode($ticket);
                } else {
                    http_response_code(500);
                    echo 'An error occurred. No tour found';
                }
            } else {
                http_response_code(500);
                echo 'An error occurred. Get tour error: '. $connect->error;
            }
        } else {
            http_response_code(500);
            echo 'An error occurred';
        }
    } else{
        http_response_code(500);
    	echo 'An error occurred. Get ticket error: '. $connect->error;
    }
} else{
    http_response_code(500);
	echo "An error occurred. Insert ticket error: ". $connect->error;
}
?>