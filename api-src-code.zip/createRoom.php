<?php
require_once "connectDB.php";

$userId = $_POST['userId'];
$name = $_POST['name'];
$member = $_POST['member'];
$image = null;

$key = "image";
if (isset($_FILES[$key]) and $_FILES[$key]['error'] == 0) {
    $file = $_FILES[$key];
    $allowType = array('jpg', 'png', 'jpeg');
    $fileType = pathinfo($file["name"],PATHINFO_EXTENSION);
    if (!in_array($fileType,$allowType)) {
        die("Require image is JPG, PNG, JPEG");
    }
    $target_file = "../images/". bin2hex(random_bytes(16)). ".". $fileType;
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        $image = $target_file;
    } else {
        http_response_code(400);
        die("Update image error. ".$target_file);
    }
}

$query = "INSERT INTO chat_room VALUES(null, '$userId', '$name', '$image', '$member')";
if (mysqli_query($connect, $query)) {
    $roomId = $connect->insert_id;
    $time = round(microtime(true) * 1000);
    $query = "INSERT INTO user_chat_room VALUES(null, '$userId', '$roomId', '$name', '$image', '', '0', '$time', true)";
    if (mysqli_query($connect, $query)) {
        $member = json_decode($member);
        foreach ($member as &$memberId) {
            $query = "INSERT INTO user_chat_room VALUES(null, '$memberId', '$roomId', '$name', '$image', '', '0', '$time', false)";
            if (!mysqli_query($connect, $query)) {
                http_response_code(500);
                die ('An error occurred. ' .$connect->error);
            }
        }
        $query = "SELECT * FROM user_chat_room WHERE id = $connect->insert_id LIMIT 1";
        $data = mysqli_query($connect, $query);
        if ($data && !empty($room = mysqli_fetch_assoc($data))) {
        	echo json_encode($room);
        } else{
            http_response_code(500);
        	echo 'An error occurred. ' .$connect->error;
        }
    } else {
        http_response_code(500);
    	echo "An error occurred. ". $connect->error;
    }
} else{
    http_response_code(500);
	echo "An error occurred. ". $connect->error;
}

?>