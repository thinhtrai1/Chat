<?php

require_once "connectDB.php";

$userId = htmlspecialchars($_GET["userId"]);
$search = htmlspecialchars($_GET["search"]);
$page = htmlspecialchars($_GET["page"]);
$data = mysqli_query($connect, "SELECT * FROM user_chat_room WHERE userId = '$userId' AND name LIKE '%$search%' ORDER BY lastMessageTime DESC LIMIT 20");

if(!$data){
    http_response_code(500);
    die('An error occurred' .$connect->error);
}

$arrayTour = array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayTour, $row);
}
echo json_encode($arrayTour);

?>