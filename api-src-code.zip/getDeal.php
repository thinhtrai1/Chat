<?php

$deals = array();
array_push($deals, (object) [
    'discount' => '20',
    'description' => 'Only available every Wednesday and Thursday',
    'image' => 'images/deal_1.jpg'
]);
array_push($deals, (object) [
    'discount' => '40',
    'description' => 'October 31st is coming. Have fun with friends on Halloween',
    'image' => 'images/deal_2.jpeg'
]);
array_push($deals, (object) [
    'discount' => '40',
    'description' => "Tet has come and you missed the buses go home. Don't worried. We are always with you at all times",
    'image' => 'images/deal_3.jpg'
]);

header('Content-type: application/json');
echo json_encode($deals);

?>