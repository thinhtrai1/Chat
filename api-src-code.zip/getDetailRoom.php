<?php
require_once "connectDB.php";

$userId = htmlspecialchars($_GET["userId"]);
$roomId = htmlspecialchars($_GET["roomId"]);

$query = "SELECT * FROM chat_room WHERE id = $roomId LIMIT 1";
if ($room = mysqli_query($connect, $query)) {
    $room = mysqli_fetch_assoc($room);
    $room['roomId'] = $room['id'];
    $room['isHost'] = $room['userId'] == $userId;
    $memberIds = join(', ', json_decode($room['member']));
    $query = "SELECT * FROM user WHERE id IN ($memberIds)";
    if ($data = mysqli_query($connect, $query)) {
        $users = array();
        while ($user = mysqli_fetch_assoc($data)) {
        	array_push($users, $user);
        }
        $room['member'] = $users;
        echo json_encode($room);
    } else {
        http_response_code(500);
        die('An error occurred. ' .$connect->error);
    }
} else {
    http_response_code(500);
    die('An error occurred. ' .$connect->error);
}
?>