<?php

require_once "connectDB.php";

$userId = htmlspecialchars($_GET["userId"]);
$roomId = htmlspecialchars($_GET["roomId"]);
$search = htmlspecialchars($_GET["search"]);
$query;
if(($latestTime = htmlspecialchars($_GET["latestTime"])) > 0) {
    if (empty($search)) {
        $query = "SELECT * FROM message WHERE roomId = $roomId AND time < $latestTime ORDER BY ID DESC LIMIT 31";
    } else {
        $query = "SELECT * FROM message WHERE message LIKE '%$search%' AND type = 0 AND roomId = $roomId AND time < $latestTime ORDER BY ID DESC LIMIT 31";
    }
} else {
    if (empty($search)) {
        $query = "SELECT * FROM message WHERE roomId = $roomId ORDER BY ID DESC LIMIT 31";
    } else {
        $query = "SELECT * FROM message WHERE message LIKE '%$search%' AND type = 0 AND roomId = $roomId ORDER BY ID DESC LIMIT 31";
    }
}

$data = mysqli_query($connect, $query);
if($data) {
    $arrayMessage = array();
    while ($row = mysqli_fetch_assoc($data)) {
        array_push($arrayMessage, $row);
    }
    $arrayMessage = array_reverse($arrayMessage);
    if (count($arrayMessage) == 31) {
        array_splice($arrayMessage, 0, 1);
        $arrayMessage[0]['isLoadMore'] = true;
    }
    
    $arrayId = array();
    $arrayUser = array();
    for ($i = 0; $i < count($arrayMessage); $i++) {
        $senderId = $arrayMessage[$i]["senderId"];
        if ($senderId != $userId) {
            if (in_array($senderId, $arrayId, true)) {
                foreach ($arrayUser as $user) {
                    if ($user['id'] == $senderId) {
                        $arrayMessage[$i]["name"] = $user["name"];
                        $arrayMessage[$i]["avatar"] = $user["image"];
                        break;
                    }
                }
            } else {
                $senderId = $arrayMessage[$i]["senderId"];
                if($user = mysqli_query($connect, "SELECT id, name, image FROM user WHERE id = '$senderId' LIMIT 1")) {
                    $user = mysqli_fetch_assoc($user);
                    array_push($arrayId, $senderId);
                    array_push($arrayUser, $user);
                    $arrayMessage[$i]["name"] = $user["name"];
                    $arrayMessage[$i]["avatar"] = $user["image"];
                } else {
                    http_response_code(500);
                    die('An error occurred' .$connect->error);
                }
            }
        }
    }
} else {
    http_response_code(500);
    die('An error occurred' .$connect->error);
}

echo json_encode($arrayMessage);

?>