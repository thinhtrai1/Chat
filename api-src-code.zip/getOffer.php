<?php

class Offer {
	function Offer($id, $priceOff, $code) {
		$this -> id = $id;
		$this -> priceOff = $priceOff;
		$this -> code = $code;
	}
}

$offers = array();
array_push($offers, new Offer(0, 29.99, "JASMVWVA"));
array_push($offers, new Offer(1, 10, "2J3AHFGT"));
array_push($offers, new Offer(2, 99.99, "VWVA24S1"));
array_push($offers, new Offer(2, 49.99, "UQRAZT15"));

header('Content-type: application/json');
echo json_encode($offers);

?>