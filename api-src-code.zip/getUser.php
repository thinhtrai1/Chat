<?php

require_once "connectDB.php";

$search = htmlspecialchars($_GET["search"]);
$userId = htmlspecialchars($_GET["userId"]);
$data = mysqli_query($connect, "SELECT * FROM user WHERE (name LIKE '%$search%' OR email LIKE '%$search%') AND id != $userId ORDER BY name,email LIMIT 20");

if(!$data){
    http_response_code(500);
    die('An error occurred' .$connect->error);
}

$arrayTour = array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayTour, $row);
}
echo json_encode($arrayTour);

?>