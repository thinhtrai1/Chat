<?php
require_once "connectDB.php";

$email = $_POST['email'];
$pass = $_POST['password'];
$query = "SELECT * FROM user WHERE email = '$email' AND password = '$pass' LIMIT 1";
if ($data = mysqli_query($connect, $query)) {
    if (!empty($user = mysqli_fetch_assoc($data))) {
	    echo json_encode($user);
    } else {
        http_response_code(400);
        echo 'Email or password is incorrect';
    }
} else{
    http_response_code(500);
	echo 'An error occurred' .$connect->error;
}
?>