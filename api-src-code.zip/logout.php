<?php
require_once "connectDB.php";

$userId = $_POST['userId'];
$deviceId = $_POST['deviceId'];
if (mysqli_query($connect, "DELETE from firebase_token WHERE deviceId = '$deviceId'")) {
    echo 'Success';
} else{
    http_response_code(500);
	echo 'An error occurred. ' .$connect->error;
}
?>