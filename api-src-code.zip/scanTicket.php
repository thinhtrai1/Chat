<?php
require_once "connectDB.php";

$qrCode = htmlspecialchars($_GET["qrCode"]);
$query = "SELECT * FROM ticket WHERE qrCode = '$qrCode' LIMIT 1";
if ($data = mysqli_query($connect, $query)) {
    if (!empty($ticket = mysqli_fetch_assoc($data))) {
        $tourId = $ticket['tourId'];
        $query = "SELECT * FROM tour WHERE id = '$tourId' LIMIT 1";
        if ($data = mysqli_query($connect, $query)) {
            if (!empty($tour = mysqli_fetch_assoc($data))) {
                $ticket["seatList"] = json_decode($ticket["seatList"]);
                $ticket['tourData'] = $tour;
                $ticket['tourData']['seatSelected'] = json_decode($ticket['tourData']['seatSelected']);
        	    echo json_encode($ticket);
            } else {
                http_response_code(400);
                echo 'No tour found';
            }
        } else {
            http_response_code(500);
        	echo 'An error occurred' .$connect->error;
        }
    } else {
        http_response_code(400);
        echo "No data found for '". $qrCode. "'.";
    }
} else {
    http_response_code(500);
	echo 'An error occurred' .$connect->error;
}
?>