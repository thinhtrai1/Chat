<?php
require_once "connectDB.php";

$userId = $_POST['userId'];
$roomId = $_POST['roomId'];
$type = $_POST['type'];
$message = null;
$file = null;
$time = round(microtime(true) * 1000);

if ($type == 0) {
    $message = $_POST['message'];
} else {
    $key = "file";
    if (isset($_FILES[$key]) and $_FILES[$key]['error'] == 0) {
        $file = $_FILES[$key];
        $fileType = pathinfo($file["name"],PATHINFO_EXTENSION);
        $target_file = "../message-files/". bin2hex(random_bytes(16)). ".". $fileType;
        if (move_uploaded_file($file["tmp_name"], $target_file)) {
            $message = $target_file;
        } else {
            http_response_code(400);
            die("Move file error.");
        }
    } else {
        http_response_code(400);
        die("Upload file error.");
    }
}

$query = "INSERT INTO message VALUES(null, '$userId', '$roomId', '$message', '$type', '$time')";
if (!mysqli_query($connect, "INSERT INTO message VALUES(null, '$userId', '$roomId', '$message', '$type', '$time')")) {
    http_response_code(500);
    die ('An error occurred. ' .$connect->error);
}
$messageId = $connect->insert_id;

$query = "UPDATE user_chat_room SET lastMessage = '$message', lastMessageType = '$type', lastMessageTime = '$time' WHERE roomId = '$roomId'";
if (!mysqli_query($connect, $query)) {
    http_response_code(500);
    die ('An error occurred. ' .$connect->error);
}

// API access key from Google API's Console
define( 'API_ACCESS_KEY', 'AAAAVBYAj_s:APA91bFdYm5s6LGb7NDnVJEPdCwoKySEWGR1aYyRJyo3IiYxeBAfLvcbwYfmfw2tgDqArFOMu0CaDQJnlflsO_N6B6NCZQJ-ubkVSy70ce4c91GA5rJMWxv6m3h-mSDZMp3pcA-chaDs' );
$query = "SELECT name, member FROM chat_room WHERE id = $roomId LIMIT 1";
if ($room = mysqli_query($connect, $query)) {
    $room = mysqli_fetch_assoc($room);
    $memberIds = $room['member'];
    $memberIds = join(', ', json_decode($memberIds));
    $query = "SELECT token FROM firebase_token WHERE userId IN ($memberIds) AND userId != $userId";
    $tokens = mysqli_query($connect, $query);
    $registrationIds = array();
    while ($token = mysqli_fetch_assoc($tokens)) {
    	array_push($registrationIds, $token['token']);
    }
    $senderName = '';
    $senderImage = '';
    $query = "SELECT name, image FROM user WHERE id = $userId LIMIT 1";
    if ($user = mysqli_query($connect, $query)) {
        $user = mysqli_fetch_assoc($user);
        $senderName = $user['name'];
        $senderImage = $user['image'];
    }
    $msg = array
    (
    	'id' 	=> $messageId,
    	'message'	=> $message,
    	'messageType'		=> $type,
    	'messageTime'	=> $time,
    	'roomId'	=> $roomId,
    	'senderId'		=> $userId,
    	'senderName'	=> $senderName,
    	'senderImage'	=> $senderImage
    );
    $notificationBody = '';
    if ($type == 0) {
        $notificationBody = 'From '. $room['name']. ': '. $message;
    } else if ($type == 1) {
        $notificationBody = 'A new image from '. $room['name'];
    }
    
    $fields = array
    (
    	'registration_ids' 	=> $registrationIds,
    	'notification' 	=> array('title'=>'Chat', 'body'=> $notificationBody),
    	'data'			=> $msg
    );
     
    $headers = array
    (
    	'Authorization: key=' . API_ACCESS_KEY,
    	'Content-Type: application/json'
    );
     
    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    curl_close( $ch );
    
    $query = "SELECT * FROM message WHERE id = $messageId LIMIT 1";
    if ($message = mysqli_query($connect, $query)) {
        $message = mysqli_fetch_assoc($message);
        echo json_encode($message);
    } else {
        http_response_code(500);
        die ('An error occurred. ' .$connect->error);
    }
}
?>