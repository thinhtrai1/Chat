<?php
    $obj = (object) [
    'name' => 'some string',
    'gender' => 'thinh'
];

echo json_encode($obj);
?>