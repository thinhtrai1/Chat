<?php
require_once "connectDB.php";

$userId = $_POST['userId'];
$deviceId = $_POST['deviceId'];
$token = $_POST['token'];

if(mysqli_query($connect, "DELETE FROM firebase_token WHERE deviceId = '$deviceId'")) {
    if(mysqli_query($connect, "INSERT INTO firebase_token VALUES(null, '$userId', '$deviceId', '$token')")) {
        die ('Success');
    } else {
        http_response_code(500);
    	echo 'An error occurred. ' .$connect->error;
    }
}
?>