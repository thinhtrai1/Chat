<?php
require_once "connectDB.php";

$userId = $_POST['userId'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

$image = null;
$key = "image";

$userQuery = "SELECT * FROM user WHERE id = '$userId' LIMIT 1";
if ($data = mysqli_query($connect, $userQuery)) {
    if (!empty($user = mysqli_fetch_assoc($data))) {
        $image = $user[$key];
    } else {
        http_response_code(500);
        die('User not found');
    }
} else {
    http_response_code(500);
    die('An error occurred. '. $connect->error);
}

if (isset($_FILES[$key]) and $_FILES[$key]['error'] == 0) {
    $file = $_FILES[$key];
    $allowType = array('jpg', 'png', 'jpeg');
    $fileType = pathinfo($file["name"],PATHINFO_EXTENSION);
    if (!in_array($fileType,$allowType)) {
        die("Require image is JPG, PNG, JPEG");
    }
    $target_file = "../images/". bin2hex(random_bytes(16)). ".". $fileType;
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        if ($image !== null) {
            unlink($image);
        }
        $image = $target_file;
    } else {
        http_response_code(400);
        die("Update image error".$target_file);
    }
}

$query = "UPDATE user SET name = '$name', phone = '$phone', email = '$email', image = '$image', password = '$password' WHERE id = '$userId'";
if (mysqli_query($connect, $query)) {
    die(json_encode(mysqli_fetch_assoc(mysqli_query($connect, $userQuery))));
} else {
    http_response_code(500);
    die('An error occurred. '. $connect->error);
}

?>